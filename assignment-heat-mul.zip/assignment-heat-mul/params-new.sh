#!/bin/sh

NS="1000 10000 1000000"
POWERS="20"

PROCS="1 2 4 8 16 32"

RESULTDIR=result/
